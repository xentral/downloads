<?php

include("/root/config.php");
include("/root/wawision.php");
include("/root/class.labelprinter.php");

  class Scanner {
    var $firstip; 
    var $lastip; 
    var $ports;       
    var $wait;       
    var $delay;     
    var $scanip;  
    var $ownip;  
    var $config;  
    var $settings;  

    function Scanner($config,$settings) {
	$this->config = $config;
	$this->settings = $settings;

        sleep(15);
    	$this->ownip = $this->getServerAddress();
        $ip_array = explode('.',$this->ownip);

        $firstpart = $ip_array[0].".".$ip_array[1].".".$ip_array[2].".";
	$this->ownip = ip2long($this->ownip);

        $this->device = $this->Device();

    	$this->firstip = ip2long($firstpart."1");  /* store the start ip address as a long number */
    	$this->lastip = ip2long($firstpart."255");    /* store the end ip address as a long number */

      	$this->wait = 0.1;
      	$this->delay = 100*1000; // 100 microseconds
	$this->ports[]=80;
	$this->ports[]=443;
    }

    function Device()
    {
       $result = system("lsusb | grep Zebra");

       if($result!="")
       {
         if (strpos($result,'Zebra') !== false) {
           $printer = new LabelPrinter();
           $printer->Configure(203,50,18,3,0,6);
           $printer->Printpath("/dev/usb/lp0");
           $printer->Printamount(1);



           $macw = shell_exec('ifconfig wlan0 | grep -o -E "([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}"');
           $mace = shell_exec('ifconfig eth0 | grep -o -E "([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}"');
           $printer->Line(3,0,0,4,"WaWision Adapterbox".$match[1]);
           if(long2ip($this->ownip)!="0.0.0.0")
              $printer->Line(3,5,0,2,"IP: ".long2ip($this->ownip));
           $printer->Line(3,8.5,0,2,"Serial:     ".$this->config['serial']);
           $printer->Line(3,11,0,2,"MAC-ETH:    ".str_replace(':','/',trim($mace)));
           $printer->Line(3,13,0,2,"MAC-WLAN:   ".str_replace(':','/',trim($macw)));


           $printer->Output(1);

         return "zebra";
        }
      }
    }

    function getServerAddress() {
    	if(isset($_SERVER["SERVER_ADDR"]) && $_SERVER["SERVER_ADDR"]!="0.0.0.0")
    		return $_SERVER["SERVER_ADDR"];
    	else {
        	$ifconfig = shell_exec('/sbin/ifconfig eth0');
        	preg_match('/addr:([\d\.]+)/', $ifconfig, $match);
		if($match[1]=="0.0.0.0" || $match[1]=="")
		{
			$ifconfig = shell_exec('/sbin/ifconfig wlan0');
        		preg_match('/Adresse:([\d\.]+)/', $ifconfig, $match);
		}
        	return $match[1];
    	}
    }

    function check_wawision($ownip,$serverip,$https=false) {
	$serial = $this->config['serial'];
	if($https)
		$url = "https://".$serverip."/index.php?module=welcome&action=adapterbox&ip=$ownip&serial=$serial&device=".$this->device;
	else
		$url = "http://".$serverip."/index.php?module=welcome&action=adapterbox&ip=$ownip&serial=$serial&device=".$this->device;

      	$ch = curl_init();
      	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_NOPROGRESS, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
      	//curl_setopt($ch, CURLOPT_SSLVERSION,3); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: close'));
      	$result = curl_exec($ch);
      	curl_close($ch);
      	return $result;
   }

   function scan() {

      if($this->settings['url']!="")
      {
        $this->settings['url'] = rtrim($this->settings['url'], '/');
	$this->settings['url'] = str_replace('http://','',$this->settings['url']);
	$this->settings['url'] = str_replace('https://','',$this->settings['url']);
    	$this->check_wawision($this->ownip,$this->settings['url'],false);
    	$this->check_wawision($this->ownip,$this->settings['url'],true);
        exit;
      }


      for($this->scanip=$this->firstip; $this->scanip<=$this->lastip; $this->scanip++) {
        $ip = long2ip($this->scanip);

	//echo "scan $ip \r\n";
        
        foreach($this->ports as $key=>$port) {
        	$ptcp = @fsockopen($ip, $port, $errno, $errstr, $this->wait);
		//echo "port $port";
		if($ptcp)
		{
			if($port==443)
				$result = $this->check_wawision($this->ownip,$ip,true);
			else
				$result = $this->check_wawision($this->ownip,$ip);

			//if($result==="OK") {echo "found wawision $ip"; }
		}
		//echo "\n";

          	usleep($this->delay);
        }
      }
      return 1;
    }

  }

  $tmp = new Scanner($config,$settings);
  //$results = $tmp->scan();

  print_r($results);

?>
