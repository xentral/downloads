<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_WARNING | E_PARSE);


include("/root/class.labelprinter.php");
include("/root/config.php");
include("/root/wawision.php");
//system("sleep 5");
system("ping -c 2 8.8.8.8");

$debug=4;

$ssl3=false;

$noresults =0;

while(1)
{
  //echo ".";
  //Initialize handle and set options
  $username = $config["serial"];
  $password = $settings["devicekey"];
  $auth = generateHash($password,$username);

  $url = $settings["url"]."/devices/?cmd=getJob&device=$username&auth=$auth";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);

  //$file_handler = fopen('somefile.log', 'a');
  //curl_setopt($ch, CURLOPT_VERBOSE, $file_handler);

  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 20);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
  curl_setopt($ch, CURLOPT_NOPROGRESS, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  if($ssl3)
    curl_setopt($ch, CURLOPT_SSLVERSION,3);
  //curl_setopt($ch, CURLOPT_POSTFIELDS, "auth=$auth");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: close'));
  //curl_setopt($ch, CURLOPT_HEADER, 1 ); // Uncomment these for debugging


  // grab URL and pass it to the browser                                                                                                                       
  $result = curl_exec($ch);
  curl_close($ch);

  $xml      = simplexml_load_string( $result );
  $json     = json_encode( $xml );
  $options  = json_decode( $json, TRUE );


  if(is_array($options)) {
    system("echo 1 >/sys/class/leds/led0/brightness");
    system("echo 0 >/sys/class/leds/led0/brightness");
  }


  if($debug >= 2)
    print_r($options);

  if(is_array($options) && !$ssl3) {
    if($debug >= 2)
      echo "Found SSL < 3\r\n";
    $ssl3=false;
  }
  else {
    if($debug >= 2)
      echo "Found SSL 3\r\n";
    $ssl3=true;
  }

  if(count($options)<=1) { $noresults++; echo "noresult ($noresults)\r\n"; }
  else $noresults=0;

  if($noresults > 10) exit(0);

  if(!isset($options['device'])) $options['device']="";


  switch($options['device'])
  {
    case "display":
      echo "#";
      $text = $options['job']['display']['text'];
      ob_start();
      //system('echo -e "\x1C'.$line1."\r\n".$line2.'" > /dev/ttyUSB0');
      system('echo "'.$text.'" > /dev/ttyUSB0');
      $answer_result = ob_get_contents();
      ob_end_clean();
      $answer = 0;
      break;

    case "bondrucker":
      $tmpfp = fopen("/dev/usb/lp0","w");
      fwrite($tmpfp, base64_decode($options['job']['label']));
      fclose($tmpfp);
      break;

    case "labelprinter": 
      $job = json_decode(base64_decode($options['job']),true);
      if($job['amount'] <=0) $job['amount']=1;

      $xmlconfig = 
        '<printer>'.
        '<label width="30" height="15" />'.
        '<setting dpi="50" offsetx="0" offsety="0" />'.
        '</printer>';

      $printer = new LabelPrinter();
      $printer->LoadXML(base64_decode($job['label']));
      $printer->Output($job['amount']);
      unset($printer);
      continue;
      break;

    case "printer":

      $job = json_decode(base64_decode($options['job']),true);

      //echo $job['description'];

      if($job['amount'] <= 0) {
        $job['amount'] = 1;
      }

      if ($job['format']) {
        switch ($job['format']) {
          case 'DINA0':
            $job['format'] = 'A0';
            break;
          case 'DINA1':
            $job['format'] = 'A1';
            break;
          case 'DINA2':
            $job['format'] = 'A2';
            break;
          case 'DINA3':
            $job['format'] = 'A3';
            break;
          case 'DINA4':
            $job['format'] = 'A4';
            break;
          case 'DINA5':
            $job['format'] = 'A5';
            break;
          case 'DINA6':
            $job['format'] = 'A6';
            break;
          default:
            $job['format'] = 'A4';
            break;
        }
      } else {
        $job['format'] = 'A4';
      }

      $tmpfilename = "/tmp/bene";//tempnam("/tmp/",$customerSettings['serial']."_print");
      file_put_contents($tmpfilename,base64_decode($job['label']));

      for($i=0; $i < $job['amount']; $i++) {
        if(is_file($tmpfilename) && $tmpfilename!="" && filesize($tmpfilename) > 0) {

          $command = "lpr -o fit-to-page -o media=".$job['format']." -P '" . $job['description'] . "' " . $tmpfilename;

          system($command);
          $return['message'] = 'Drucken';

        }
      }

      if(is_file($tmpfilename) && $tmpfilename!="" && filesize($tmpfilename) > 0) {
        unlink($tmpfilename);
      }
      break;

    case "metratecrfid":
      if(!isRFIDReaderAttached()){
        $answer_result = "-1";
        $answer = 1;
        break;
      }
      if(!isRFIDDaemonRunning()){
        $answer_result = "1";
        exec("python /root/cardReader.py >/dev/null &");
      }else{
        $answer_result = file_get_contents("/root/RFIDlog.txt");
        $file = fopen("/root/RFIDlog.txt", "w");
        fwrite($file, "0");
        fclose($file);
      }
      $answer = 1;
      break;

    case "waage":
      echo "#";
      $timeout = $options['job']['waage']['settings']['@attributes']['timeout'];
      $baud = $options['job']['waage']['settings']['@attributes']['baud'];
      $chars = $options['job']['waage']['settings']['@attributes']['chars'];
      $parity = $options['job']['waage']['settings']['@attributes']['parity'];
      ob_start();
      if($parity >=1)
        system("/root/waage $baud $chars $timeout 1");
      else
        system("/root/waage $baud $chars $timeout");

      $answer_result = ob_get_contents();
      ob_end_clean();
      $answer = 1;
      break;
    case "kamera":
      $width = $options['job']['image']['settings']['@attributes']['width'];
      $height = $options['job']['image']['settings']['@attributes']['height'];
      if(is_file("/tmp/ram/kamera.jpg"))
      {
        unlink("/tmp/ram/kamera.jpg");
      }
      //echo "#";
      if($width > 0)
        system("uvccapture -o/tmp/ram/kamera.jpg -x".$width." -y".$height);
      else
        system("uvccapture -o/tmp/ram/kamera.jpg ");

      //echo "*";
      $answer_result = base64_encode(serialize(file_get_contents("/tmp/ram/kamera.jpg")));
      //echo strlen($answer_result);
      //echo ($answer_result);
      $answer = 1;
      break;

    default:
      //usleep(1000 * 200);
      sleep(1);
  }

  if($answer==1)
  {
    $answer_result_base64 = urlencode(base64_encode($answer_result));
    $url = $settings["url"]."/devices/?cmd=addJob&device=000000000&auth=$auth&request_id=".$options['id']."&art=".$options['device'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);

    //$file_handler = fopen('somefile.log', 'a');
    //curl_setopt($ch, CURLOPT_VERBOSE, $file_handler);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
    curl_setopt($ch, CURLOPT_NOPROGRESS, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    if($ssl3)
      curl_setopt($ch, CURLOPT_SSLVERSION,3);

    curl_setopt($ch, CURLOPT_POSTFIELDS, "job=$answer_result_base64");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: close'));

    // grab URL and pass it to the browser                                                                                                                       
    $result = curl_exec($ch);
    curl_close($ch);
    //echo "*";

    $answer=0;
  }

}

function isRFIDReaderAttached(){
  exec("lsusb -v | grep \"metraTec DeskID MF Reader\"", $output);
  if(empty($output)){
    return false;
  }else{
    return true;
  }
}

function isRFIDDaemonRunning(){
  exec("pgrep -f cardReader.py", $pids);
  if(sizeof($pids) == 1){
    return false;
  }else{
    return true;
  }
}


function generateHash($key,$deviceid)
{ 
  $hash = "";
  for($i = 0; $i <= 200; $i++)
    $hash = sha1($hash . $key.$deviceid);
  return $hash;
}

?>
