#include <sys/ioctl.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char *argv[])
{
  char tty[] = "/dev/ttyUSB0";
  char *device = tty;

  //argv[0] = 1 = 4800 2 = 9200
  int baud, chars, timeout, parity;
  if(argc >= 4)
  { 
    baud = strtol(argv[1],NULL,10);
    chars = strtol(argv[2],NULL,10);
    timeout =strtol(argv[3],NULL,10);
    parity=0;
  }


  if(argc >= 5)
  { 
    baud = strtol(argv[1],NULL,10);
    chars = strtol(argv[2],NULL,10);
    timeout =strtol(argv[3],NULL,10);
    parity =strtol(argv[4],NULL,10);
  }

  if(baud <=0) baud=1;
  if(chars <=0) chars=100;
  if(timeout <=0 || timeout > 100) timeout=2;

  //printf("baud %i chars %i timeout %i\r\n",baud,chars,timeout);

  int fd,res,i;
  char buf [255];
  char In1;
  int modelines=0;    
  fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
  struct termios settings;

 if(parity >=1)
 {

  settings.c_iflag=   IGNBRK       //Ignoriere BREAKS beim Input
      ;                 //Keine Parität


  settings.c_oflag=0;        
        //Keine besonderen Angaben nötig

  settings.c_cflag= CS8 | PARENB          
	// | CSTOPB               
           | CREAD            
      //Zeichen können von gelesen werden
           | CLOCAL ;               //Ignoriere Modemstatus, lokaler Anschluß
  } else {
  settings.c_iflag=   IGNBRK       //Ignoriere BREAKS beim Input
      | IGNPAR ;                 //Keine Parität


  settings.c_oflag=0;        
        //Keine besonderen Angaben nötig

  settings.c_cflag= CS8           
	// | CSTOPB               
           | CREAD            
      //Zeichen können von gelesen werden
           | CLOCAL ;               //Ignoriere Modemstatus, lokaler Anschluß

  }

  //Setzen der lokalen Flags
  settings.c_lflag=0;        
  //Festlegen der maximalen Zeit, welche beim Lesen gewartet werden soll
  settings.c_cc[VTIME]=10;  //Geräte mit höheren 

  //Festlegen der minimalen Anzahl der zu lesenden Bytes -> Fall 3

  settings.c_cc[VMIN]=0;

  switch(baud)
  {
  case 1: cfsetspeed(&settings,B4800); break;
  case 2: cfsetspeed(&settings,B9600); break;
  default:
     cfsetspeed(&settings,B4800);
  }

  tcsetattr(fd,TCSANOW,&settings);


  ioctl(fd,TIOCMGET,&modelines);

  /*Setzen des RTS-Signals*/
  modelines &= ~TIOCM_RTS;
  ioctl(fd,TIOCMSET,&modelines);

  int index;
  unsigned char puffer[255];

  index=0;

  int found_start=0;

  int mindestens_werte = 0;
  long timeout_counter = 0;

    while(1){
        res = read(fd,buf,1);
        timeout_counter++;
        if(timeout_counter > 70000 * timeout)
        {
		printf("timeout"); break;
        }
        for(i=0;i<res;i++){
            puffer[index++] = buf[i];
	    mindestens_werte ++;
        }
		
	if(mindestens_werte > chars)
	{
        	for(i=0;i<mindestens_werte;i++)
			printf("%c",puffer[i]);

		printf("\n");
		break;
	} 
    }
return 0;
}
